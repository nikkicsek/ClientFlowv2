import { GoogleCalendarService } from '../calendar/GoogleCalendarService';
import { Pool } from 'pg';

// expects app.set('db', pool) somewhere in your server bootstrap
export function makeCalendarHooks(db: Pool) {
  const svc = new GoogleCalendarService(db);
  return {
    onTaskCreatedOrUpdated: async (taskId: string) => {
      await svc.reconcileTask(taskId);
    },
    onTaskDeleted: async (taskId: string) => {
      // delete all assignment events
      const assignments = await (global as any).storage.getTaskAssignments(taskId);
      for (const a of assignments) {
        try { await svc.deleteForAssignment(a.id); } catch {}
      }
    },
    onAssignmentCreated: async (assignmentId: string) => {
      await svc.upsertForAssignment(assignmentId);
    },
    onAssignmentDeleted: async (assignmentId: string) => {
      await svc.deleteForAssignment(assignmentId);
    }
  };
}

export const { onTaskCreatedOrUpdated, onTaskDeleted, onAssignmentCreated, onAssignmentDeleted } = makeCalendarHooks((global as any).db as Pool);
